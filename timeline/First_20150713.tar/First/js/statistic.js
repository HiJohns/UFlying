var _data = {
    finish: 234,
    trading: 134,
    com_num: 5623,
    investor: 9
};

var _format = {
    finish: 3,
    trading: 2,
    com_num: 5,
    investor: 4
};

$(document).ready(function () {
    $('.odometer').each(function () {
        var value = _data[this.id];
        var format = _format[this.id];

        var stack = [];
        while (format-- > 0) {
            stack.push((value % 10).toString());
            value = (value - (value % 10)) / 10;
        }

        for (var i = stack.length - 1; i >= 0; i--) {
            $('<span>').text(stack[i]).appendTo(this);
        }
    });
});

